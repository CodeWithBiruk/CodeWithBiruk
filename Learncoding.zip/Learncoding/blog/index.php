<?php 
    session_start();
    if (!isset($_SESSION['id'])) {
        # code...
        header('Location: ../get-started');
    }
    $id = $_SESSION['id'];
    require '../includes/DB_Connect.php';
    $sql = $con->query("SELECT * FROM users WHERE id='$id'");
    $data = $sql->fetch_assoc();
    $_SESSION['name'] = $data['name'];
    $_SESSION['email'] = $data['email'];;

    $sql = $con->query("SELECT id FROM users");
    $membercount = $sql->num_rows;
 ?>
<!DOCTYPE html>
<html>
<head>
	<!-- meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Website Title -->
	<title>Learn-coding - Blog Page</title>
	<!-- Link Some Style Sheet -->
    <link rel="stylesheet" type="text/css" href="../assets/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/animate.css">
    <link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <link rel="shortcut icon" href="../assets/img/logo.png"> 
</head>
<body>
    <header> 
        <div class="logo animated bounceInLeft">
            <img src="../assets/img/logo.png" height="45px" width="50px">
        </div>
        <nav class="nav-main animated bounceInRight">
            <ul>
                <li><a href="../">Home</a></li>
                <li><a href="./about/">About</a></li>
                <li><a href="../blog/">Blog</a></li>
                <li><a href="../contact/">Contact</a></li>
                <li><a href="../">Coding tips</a></li>
                <li><a href="../courses/">Coures</a></li>
            </ul>
        </nav>
        <div class="menu-toggle">
            <svg xmlns="http://www.w3.org/2000/svg" height="25px" width="30px" fill="#fff" viewBox="0 0 448 512"><path d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"/></svg>
        </div>
        
    </header>
    <!-- Header-End -->
    <div class="container1">
        <div class="main">
        <h1>Blog</h1>
        <div class="border"></div>
        <form style="float: right; display: flex;">
            <input type="text" placeholder="Find a Blog..." name="course" id="search" class="form-control">
            <button type="submit" class="btn btn-primary" style="height: 45px; margin-top: 10px;">Search</button>
        </form>
        <form style="float: center;" action="../includes/blog.inc.php">
            <input type="text" name="title" placeholder="Title" class="form-control"  required="">
            <textarea name="content" rows="8" cols="30" placeholder="Write something in your mind..." class="form-control" required=""></textarea>
            <select class="form-control" name="gender" style="color: #000;" id="category" required="">
                <option value="pro">Programing</option>
                <option value="hack">Hacking</option>
                <option value="other">Other</option>
            </select>
            <input type="submit" name="post" class="btn btn-primary" value="post" style="float: right;">
        </form>
            <?php
                    $squl = "SELECT * FROM cms";
                    $result = mysqli_query($con, $squl);
                    $queryResults = mysqli_num_rows($result);
                    $like = 0;
                    if ($queryResults > 0) {
                     while ($row = mysqli_fetch_assoc($result)) {
                        echo "
                        <br><br>
                        <div class='each-blog'>
                            <div class='info'>
                                <p class='text-center parag01 pt-5'>Hacking Blog</p>
                                <h5 class='text-center cat' style='float: left; text-transform: uppercase;'>".$row['title']."</h5><br><br>
                                <p class='cat' style='text-transform: uppercase; float: left;'>".$row['content']."</p>
                            </div>
                        </div>
                        ";
                     }
                 }
            ?>
    </div>
    	<!-- Adveting -->
        <div class="advert">
            <div class="advert-item">
                <div class="advert-item-intro">
                        short notice
                </div>
                <div class="advert-main-part">
                    <p class="parag">
                        Please feedback any invalid site links you met at Learn coding via our E-mail: <a href="mailto:info@Learncoding.com" class="here">Learncoding@gmail.com</a>, including both post link and how to link(s). Then I will try to fix all links You have mentioned as fast as I can. Doing this will help us to improve Learn coding from day to day.
                    </p>
                </div>
            </div><br>
            <div class="advert-item">
                <div class="advert-item-intro">
                        Google Search
                </div>
                <div class="advert-main-part">
                    <form class="google" action="https://www.google.com/" method="GET">
                        <center><img src="../assets/img/google.png" alt="Google Logo" height="60px" width="100px"></center>
                        <input type="text" name="q">
                        <input type="submit" value="search">
                    </form>
                </div>
            </div><br>
            <div class="advert-item">
                <div class="advert-item-intro">
                        Keep in touch
                </div>
                <div class="advert-main-part">
                        <a style="text-decoration: none;" href="http://facebook.com">
                            <button class="fb">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" focusable="false" width="20" height="20"><path fill="#fff" d="M 17.78 27.5 V 17.008 h 3.522 l 0.527 -4.09 h -4.05 v -2.61 c 0 -1.182 0.33 -1.99 2.023 -1.99 h 2.166 V 4.66 c -0.375 -0.05 -1.66 -0.16 -3.155 -0.16 c -3.123 0 -5.26 1.905 -5.26 5.405 v 3.016 h -3.53 v 4.09 h 3.53 V 27.5 h 4.223 Z" /></svg>
                                <p>Find on Facebook</p>
                            </button>
                            </a>
                        <br>
                        <a style="text-decoration: none;" href="http://twitter.com">
                        <button class="twitter">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" focusable="false" width="20" height="20"><path fill="#fff" d="M 28 8.557 a 9.913 9.913 0 0 1 -2.828 0.775 a 4.93 4.93 0 0 0 2.166 -2.725 a 9.738 9.738 0 0 1 -3.13 1.194 a 4.92 4.92 0 0 0 -3.593 -1.55 a 4.924 4.924 0 0 0 -4.794 6.049 c -4.09 -0.21 -7.72 -2.17 -10.15 -5.15 a 4.942 4.942 0 0 0 -0.665 2.477 c 0 1.71 0.87 3.214 2.19 4.1 a 4.968 4.968 0 0 1 -2.23 -0.616 v 0.06 c 0 2.39 1.7 4.38 3.952 4.83 c -0.414 0.115 -0.85 0.174 -1.297 0.174 c -0.318 0 -0.626 -0.03 -0.928 -0.086 a 4.935 4.935 0 0 0 4.6 3.42 a 9.893 9.893 0 0 1 -6.114 2.107 c -0.398 0 -0.79 -0.023 -1.175 -0.068 a 13.953 13.953 0 0 0 7.55 2.213 c 9.056 0 14.01 -7.507 14.01 -14.013 c 0 -0.213 -0.005 -0.426 -0.015 -0.637 c 0.96 -0.695 1.795 -1.56 2.455 -2.55 Z" /></svg>
                                <p>Find on Twitter</p>
                            </button>
                            </a>
                </div>
            </div><br>
            <div class="advert-item">
                <div class="advert-item-intro">
                        Recent post
                </div>
                <div class="advert-main-part">
                    <a class="here parag" href="#">Computer science vs software enginer - which one is Better major</a>
                    <hr class="horizontal-side-bar">
                    <a class="here parag" href="#">Top 5 programing Language in 2020 to Get a Job with out a collage degree.</a>
                    <hr class="horizontal-side-bar">
                    <a class="here parag" href="#">Top 10 popular website which built python/ Django</a>
                    <hr class="horizontal-side-bar">
                    <a class="here parag" href="#">Top 10 Most Frequently Asked by Google interview for software enginer</a>
                </div>
            </div><br>
        </div>
    </div>
    <footer>
        <div class="site-links">
            <p class="parag9" align="center">Site Links</p>
            <center>
                <ul class="footer-links" align="center">
                    <li><a href="./">Home</a></li>
                    <li><a href="./about">About</a></li>
                    <li><a href="./blog">Blog</a></li>
                    <li><a href="./contact">Coures</a></li>
                    <li><a href="./contact">Contact</a></li>
                </ul>
            </center>
        </div>
        <div class="social-media">
            <p class="parag9" align="center">Social Media</p>
            <ul class="footer-links" align="center">
                <center>
                    <li><a href="">Facebook | @Learncoding</a></li>
                    <li><a href="">Twitter | @Learncoding</a></li>
                    <li><a href="">Instagram | @Learncoding</a></li>
                    <li><a href="">Github | @Learncoding</a></li>
                    <li><a href="">Reddit | @Learncoding</a></li>
                </center>
            </ul>
        </div>
        <div class="search-this">
            <p class="parag9" align="center">Search this Blog</p>
            <ul>
                <center>
                    <form class="form-search">
                        <input type="search" name="search-input" placeholder="Search This Blog..." class="search-input" required="">
                        <br>
                        <input type="submit" name="btn-search" value="Search" class="btn-search">
                    </form>
                </center>
            </ul>
        </div>
    </footer>
    <div id="footer-sec">
        <center>Copyright (c) 2019 Learn Coding All Rights Reserved.</center>
    </div>
        <!-- <div class="newsletter">
        <a href="javascript:void()" class="ignore">✕</a>
        <p class="parag5" align="center">Subscribe to Our Newsletter</p>
        <p class="parag6" align="center">Subscribe to Our Newsletter to get latest updates from Learn coding.</p>
        <center><div class="error"></div></center>
              <form class="form">
                  <input type="email" name="email" class="email" placeholder="Email...">
                  <input type="submit" name="btn" class="btn1" value="Subscribe">
              </form>
    </div> -->

    <div class="preloader">
        <div class="loader"></div>
    </div>
    <div class="backtotop">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="#fff" width="30" height="30" ><path d="M34.9 289.5l-22.2-22.2c-9.4-9.4-9.4-24.6 0-33.9L207 39c9.4-9.4 24.6-9.4 33.9 0l194.3 194.3c9.4 9.4 9.4 24.6 0 33.9L413 289.4c-9.5 9.5-25 9.3-34.3-.4L264 168.6V456c0 13.3-10.7 24-24 24h-32c-13.3 0-24-10.7-24-24V168.6L69.2 289.1c-9.3 9.8-24.8 10-34.3.4z"/></svg>
    </div>

    <script type="text/javascript" src="../assets/js/app.js"></script>
    <script type="text/javascript" src="../assets/js/jquery.min.js"></script>

    <script type="text/javascript">
    $(window).on('load', function(){
        $('.preloader').addClass('complete');
    });
    $(document).ready(function(){
        $('.menu-toggle').click(function(){
            $('nav').toggleClass('active');
        });

    });
    </script>
</body>
</html>
</body>
</html>