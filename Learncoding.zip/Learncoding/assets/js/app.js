 var backToTop = document.querySelector('.backtotop');
 window.addEventListener('scroll', function() {
 if (window.pageYOffset > 300) {
     backToTop.style.display = "block";
 }
 else {
     backToTop.style.display = "none";
 }
 });
 document.querySelector('.backtotop').addEventListener('click', scrollFunc);
 function scrollFunc(){
     window.scrollTo(0,0);
 }
 